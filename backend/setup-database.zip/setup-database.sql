-- ============================================================
-- DMS Issue Tracker — Full Database Setup Script
-- ============================================================
-- Run this script on SQL Server to create the database,
-- all tables, and all stored procedures.
--
-- Usage:
--   1. Open SQL Server Management Studio (SSMS)
--   2. Connect to your SQL Server instance
--   3. Open this file and click Execute (F5)
--
-- This script is safe to re-run (idempotent):
--   - Database is created only if it doesn't exist
--   - Tables are created only if they don't exist
--   - Stored procedures use CREATE OR ALTER
-- ============================================================

-- ── Step 1: Create Database ──
IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = 'DMS_IssueTracker')
    CREATE DATABASE DMS_IssueTracker;
GO

USE DMS_IssueTracker;
GO

-- ============================================================
-- TABLES
-- ============================================================

-- 1. Issues (main table)
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Issues')
CREATE TABLE Issues (
    Id               INT IDENTITY(1,1) PRIMARY KEY,
    ProcessId        NVARCHAR(100)  NOT NULL,
    TaskId           NVARCHAR(100)  NOT NULL,
    IssueDate        DATETIME2      NOT NULL,
    IssueRaisedBy    NVARCHAR(100)  NOT NULL,
    IssueTitle       NVARCHAR(500)  NOT NULL,
    IssueDescription NVARCHAR(MAX)  NOT NULL DEFAULT '',
    Status           NVARCHAR(50)   NOT NULL DEFAULT 'New',
    Severity         NVARCHAR(50)   NOT NULL,
    AssignedTo       NVARCHAR(100)  NOT NULL,
    AssigningDate    DATETIME2      NULL,
    DueDate          DATETIME2      NULL,
    CurrentVersion   INT            NOT NULL DEFAULT 1,
    ReopenCount      INT            NOT NULL DEFAULT 0,
    CreatedAt        DATETIME2      NOT NULL DEFAULT SYSUTCDATETIME(),
    UpdatedAt        DATETIME2      NOT NULL DEFAULT SYSUTCDATETIME()
);
GO

-- 2. IssueDependentProcesses
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'IssueDependentProcesses')
CREATE TABLE IssueDependentProcesses (
    Id        INT IDENTITY(1,1) PRIMARY KEY,
    IssueId   INT            NOT NULL REFERENCES Issues(Id) ON DELETE CASCADE,
    ProcessId NVARCHAR(100)  NOT NULL
);
GO

-- 3. FileAttachments
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'FileAttachments')
CREATE TABLE FileAttachments (
    Id          INT IDENTITY(1,1) PRIMARY KEY,
    IssueId     INT            NOT NULL REFERENCES Issues(Id) ON DELETE CASCADE,
    FileName    NVARCHAR(500)  NOT NULL,
    FileSize    BIGINT         NOT NULL,
    ContentType NVARCHAR(200)  NOT NULL,
    DataUrl     NVARCHAR(MAX)  NOT NULL
);
GO

-- 4. IssueVersions
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'IssueVersions')
CREATE TABLE IssueVersions (
    Id             INT IDENTITY(1,1) PRIMARY KEY,
    IssueId        INT            NOT NULL REFERENCES Issues(Id) ON DELETE CASCADE,
    VersionNumber  INT            NOT NULL,
    CreatedDate    DATETIME2      NOT NULL DEFAULT SYSUTCDATETIME(),
    AssignedTo     NVARCHAR(100)  NOT NULL,
    AssigningDate  DATETIME2      NULL,
    DueDate        DATETIME2      NULL,
    Status         NVARCHAR(50)   NOT NULL,
    ReopenReason   NVARCHAR(MAX)  NULL,
    ChangesSummary NVARCHAR(MAX)  NULL
);
GO

-- Migration: Add ChangesSummary column if table already exists without it
IF NOT EXISTS (
    SELECT 1 FROM sys.columns
    WHERE object_id = OBJECT_ID('IssueVersions') AND name = 'ChangesSummary'
)
ALTER TABLE IssueVersions ADD ChangesSummary NVARCHAR(MAX) NULL;
GO

-- 5. Resolutions
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Resolutions')
CREATE TABLE Resolutions (
    Id                 INT IDENTITY(1,1) PRIMARY KEY,
    IssueId            INT            NOT NULL REFERENCES Issues(Id) ON DELETE CASCADE,
    VersionNumber      INT            NOT NULL,
    ResolvedDate       DATETIME2      NOT NULL DEFAULT SYSUTCDATETIME(),
    ResolvedBy         NVARCHAR(100)  NOT NULL,
    ResolutionNotes    NVARCHAR(MAX)  NOT NULL DEFAULT '',
    RootCause          NVARCHAR(MAX)  NOT NULL DEFAULT '',
    PreventiveMeasures NVARCHAR(MAX)  NOT NULL DEFAULT '',
    VerificationDate   DATETIME2      NULL
);
GO

-- 6. ResolutionTesters
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'ResolutionTesters')
CREATE TABLE ResolutionTesters (
    Id           INT IDENTITY(1,1) PRIMARY KEY,
    ResolutionId INT            NOT NULL REFERENCES Resolutions(Id) ON DELETE CASCADE,
    UserId       NVARCHAR(100)  NOT NULL
);
GO

-- 7. DependentProcessTestResults
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'DependentProcessTestResults')
CREATE TABLE DependentProcessTestResults (
    Id           INT IDENTITY(1,1) PRIMARY KEY,
    ResolutionId INT            NULL REFERENCES Resolutions(Id),
    VersionId    INT            NULL REFERENCES IssueVersions(Id),
    ProcessId    NVARCHAR(100)  NOT NULL,
    Tested       BIT            NOT NULL DEFAULT 0,
    TestDate     DATETIME2      NULL
);
GO

-- 8. TestResultTesters
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'TestResultTesters')
CREATE TABLE TestResultTesters (
    Id           INT IDENTITY(1,1) PRIMARY KEY,
    TestResultId INT            NOT NULL REFERENCES DependentProcessTestResults(Id) ON DELETE CASCADE,
    UserId       NVARCHAR(100)  NOT NULL
);
GO

-- ============================================================
-- STORED PROCEDURES (20)
-- ============================================================

-- ── Issues ──

CREATE OR ALTER PROCEDURE sp_GetAllIssues
AS
BEGIN
    SET NOCOUNT ON;
    SELECT * FROM Issues ORDER BY CreatedAt DESC;
END
GO

CREATE OR ALTER PROCEDURE sp_GetIssueById
    @Id INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT * FROM Issues WHERE Id = @Id;
END
GO

CREATE OR ALTER PROCEDURE sp_CreateIssue
    @ProcessId        NVARCHAR(100),
    @TaskId           NVARCHAR(100),
    @IssueDate        DATETIME2,
    @IssueRaisedBy    NVARCHAR(100),
    @IssueTitle       NVARCHAR(500),
    @IssueDescription NVARCHAR(MAX),
    @Status           NVARCHAR(50),
    @Severity         NVARCHAR(50),
    @AssignedTo       NVARCHAR(100),
    @AssigningDate    DATETIME2 = NULL,
    @DueDate          DATETIME2 = NULL,
    @CurrentVersion   INT = 1,
    @ReopenCount      INT = 0
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO Issues
        (ProcessId, TaskId, IssueDate, IssueRaisedBy, IssueTitle, IssueDescription,
         Status, Severity, AssignedTo, AssigningDate, DueDate,
         CurrentVersion, ReopenCount, CreatedAt, UpdatedAt)
    VALUES
        (@ProcessId, @TaskId, @IssueDate, @IssueRaisedBy, @IssueTitle, @IssueDescription,
         @Status, @Severity, @AssignedTo, @AssigningDate, @DueDate,
         @CurrentVersion, @ReopenCount, SYSUTCDATETIME(), SYSUTCDATETIME());
    SELECT CAST(SCOPE_IDENTITY() AS INT);
END
GO

CREATE OR ALTER PROCEDURE sp_UpdateIssue
    @Id               INT,
    @IssueTitle       NVARCHAR(500),
    @IssueDescription NVARCHAR(MAX),
    @Status           NVARCHAR(50),
    @Severity         NVARCHAR(50),
    @AssignedTo       NVARCHAR(100),
    @AssigningDate    DATETIME2 = NULL,
    @DueDate          DATETIME2 = NULL,
    @CurrentVersion   INT,
    @ReopenCount      INT
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE Issues SET
        IssueTitle       = @IssueTitle,
        IssueDescription = @IssueDescription,
        Status           = @Status,
        Severity         = @Severity,
        AssignedTo       = @AssignedTo,
        AssigningDate    = @AssigningDate,
        DueDate          = @DueDate,
        CurrentVersion   = @CurrentVersion,
        ReopenCount      = @ReopenCount,
        UpdatedAt        = SYSUTCDATETIME()
    WHERE Id = @Id;
END
GO

CREATE OR ALTER PROCEDURE sp_DeleteIssue
    @Id INT
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRANSACTION;
    -- 1. Delete test-result testers linked via Resolutions
    DELETE trt FROM TestResultTesters trt
        INNER JOIN DependentProcessTestResults dptr ON trt.TestResultId = dptr.Id
        INNER JOIN Resolutions r ON dptr.ResolutionId = r.Id
        WHERE r.IssueId = @Id;
    -- 2. Delete test-result testers linked via IssueVersions
    DELETE trt FROM TestResultTesters trt
        INNER JOIN DependentProcessTestResults dptr ON trt.TestResultId = dptr.Id
        INNER JOIN IssueVersions v ON dptr.VersionId = v.Id
        WHERE v.IssueId = @Id;
    -- 3. Delete dep test results linked via Resolutions
    DELETE dptr FROM DependentProcessTestResults dptr
        INNER JOIN Resolutions r ON dptr.ResolutionId = r.Id
        WHERE r.IssueId = @Id;
    -- 4. Delete dep test results linked via IssueVersions
    DELETE dptr FROM DependentProcessTestResults dptr
        INNER JOIN IssueVersions v ON dptr.VersionId = v.Id
        WHERE v.IssueId = @Id;
    -- 5. Delete resolution testers
    DELETE rt FROM ResolutionTesters rt
        INNER JOIN Resolutions r ON rt.ResolutionId = r.Id
        WHERE r.IssueId = @Id;
    -- 6. Delete resolutions
    DELETE FROM Resolutions WHERE IssueId = @Id;
    -- 7. Delete versions
    DELETE FROM IssueVersions WHERE IssueId = @Id;
    -- 8. Delete dependent processes
    DELETE FROM IssueDependentProcesses WHERE IssueId = @Id;
    -- 9. Delete attachments
    DELETE FROM FileAttachments WHERE IssueId = @Id;
    -- 10. Delete the issue itself
    DELETE FROM Issues WHERE Id = @Id;
    COMMIT TRANSACTION;
END
GO

-- ── Dependent Processes ──

CREATE OR ALTER PROCEDURE sp_DeleteDependentProcesses
    @IssueId INT
AS
BEGIN
    SET NOCOUNT ON;
    DELETE FROM IssueDependentProcesses WHERE IssueId = @IssueId;
END
GO

CREATE OR ALTER PROCEDURE sp_AddDependentProcess
    @IssueId   INT,
    @ProcessId NVARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO IssueDependentProcesses (IssueId, ProcessId) VALUES (@IssueId, @ProcessId);
END
GO

CREATE OR ALTER PROCEDURE sp_GetDependentProcesses
    @IssueId INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT ProcessId FROM IssueDependentProcesses WHERE IssueId = @IssueId;
END
GO

-- ── Attachments ──

CREATE OR ALTER PROCEDURE sp_AddAttachment
    @IssueId     INT,
    @FileName    NVARCHAR(500),
    @FileSize    BIGINT,
    @ContentType NVARCHAR(200),
    @DataUrl     NVARCHAR(MAX)
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO FileAttachments (IssueId, FileName, FileSize, ContentType, DataUrl)
    VALUES (@IssueId, @FileName, @FileSize, @ContentType, @DataUrl);
END
GO

CREATE OR ALTER PROCEDURE sp_GetAttachments
    @IssueId INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT * FROM FileAttachments WHERE IssueId = @IssueId;
END
GO

-- ── Versions ──

CREATE OR ALTER PROCEDURE sp_AddVersion
    @IssueId        INT,
    @VersionNumber  INT,
    @AssignedTo     NVARCHAR(100),
    @AssigningDate  DATETIME2 = NULL,
    @DueDate        DATETIME2 = NULL,
    @Status         NVARCHAR(50),
    @ReopenReason   NVARCHAR(MAX) = NULL,
    @ChangesSummary NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO IssueVersions
        (IssueId, VersionNumber, CreatedDate, AssignedTo, AssigningDate, DueDate, Status, ReopenReason, ChangesSummary)
    VALUES
        (@IssueId, @VersionNumber, SYSUTCDATETIME(), @AssignedTo, @AssigningDate, @DueDate, @Status, @ReopenReason, @ChangesSummary);
    SELECT CAST(SCOPE_IDENTITY() AS INT);
END
GO

CREATE OR ALTER PROCEDURE sp_GetVersions
    @IssueId INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT * FROM IssueVersions WHERE IssueId = @IssueId ORDER BY VersionNumber;
END
GO

-- ── Resolutions ──

CREATE OR ALTER PROCEDURE sp_AddResolution
    @IssueId            INT,
    @VersionNumber      INT,
    @ResolvedBy         NVARCHAR(100),
    @ResolutionNotes    NVARCHAR(MAX),
    @RootCause          NVARCHAR(MAX) = '',
    @PreventiveMeasures NVARCHAR(MAX) = '',
    @VerificationDate   DATETIME2 = NULL
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO Resolutions
        (IssueId, VersionNumber, ResolvedDate, ResolvedBy, ResolutionNotes, RootCause, PreventiveMeasures, VerificationDate)
    VALUES
        (@IssueId, @VersionNumber, SYSUTCDATETIME(), @ResolvedBy, @ResolutionNotes, @RootCause, @PreventiveMeasures, @VerificationDate);
    SELECT CAST(SCOPE_IDENTITY() AS INT);
END
GO

CREATE OR ALTER PROCEDURE sp_GetLatestResolution
    @IssueId INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT TOP 1 * FROM Resolutions WHERE IssueId = @IssueId ORDER BY VersionNumber DESC;
END
GO

CREATE OR ALTER PROCEDURE sp_AddResolutionTester
    @ResolutionId INT,
    @UserId       NVARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO ResolutionTesters (ResolutionId, UserId) VALUES (@ResolutionId, @UserId);
END
GO

CREATE OR ALTER PROCEDURE sp_GetResolutionTesters
    @ResolutionId INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT UserId FROM ResolutionTesters WHERE ResolutionId = @ResolutionId;
END
GO

-- ── Dependent Process Test Results ──

CREATE OR ALTER PROCEDURE sp_AddDepTestResult
    @ResolutionId INT = NULL,
    @VersionId    INT = NULL,
    @ProcessId    NVARCHAR(100),
    @Tested       BIT,
    @TestDate     DATETIME2 = NULL
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO DependentProcessTestResults (ResolutionId, VersionId, ProcessId, Tested, TestDate)
    VALUES (@ResolutionId, @VersionId, @ProcessId, @Tested, @TestDate);
    SELECT CAST(SCOPE_IDENTITY() AS INT);
END
GO

CREATE OR ALTER PROCEDURE sp_GetDepTestResults
    @ResolutionId INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT * FROM DependentProcessTestResults WHERE ResolutionId = @ResolutionId;
END
GO

CREATE OR ALTER PROCEDURE sp_AddTestResultTester
    @TestResultId INT,
    @UserId       NVARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO TestResultTesters (TestResultId, UserId) VALUES (@TestResultId, @UserId);
END
GO

CREATE OR ALTER PROCEDURE sp_GetTestResultTesters
    @TestResultId INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT UserId FROM TestResultTesters WHERE TestResultId = @TestResultId;
END
GO

-- ============================================================
-- Setup complete!
-- Database: DMS_IssueTracker
-- Tables:   8
-- Stored Procedures: 20
-- ============================================================
PRINT '✓ DMS_IssueTracker database setup completed successfully.';
GO
